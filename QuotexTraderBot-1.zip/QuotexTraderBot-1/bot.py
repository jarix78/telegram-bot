import logging
import time
import sys
from telegram.ext import Application, CommandHandler, CallbackQueryHandler
from telegram import Update
from constants import TOKEN
from handlers import start_command, menu_command, button_callback, error_handler
from keep_alive import keep_alive
from models import init_db

# Enable logging with more detailed formatting
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

# Set up logger
logger = logging.getLogger(__name__)

def main():
    """Start the bot with enhanced error handling and auto-restart capability"""
    retry_count = 0
    max_retries = 5
    retry_delay = 10  # seconds

    while True:  # Main loop to keep the bot running forever
        try:
            # Initialize database
            init_db()
            logger.info("Database initialized successfully")

            # Create application
            application = Application.builder().token(TOKEN).build()

            # Add handlers
            application.add_handler(CommandHandler("start", start_command))
            application.add_handler(CommandHandler("menu", menu_command))
            application.add_handler(CallbackQueryHandler(button_callback))
            application.add_error_handler(error_handler)

            # Start keep alive server
            keep_alive()
            logger.info("Keep alive server started - Bot will stay online 24/7")

            # Reset retry count on successful start
            retry_count = 0

            # Start the bot
            logger.info("Starting bot in 24/7 mode...")
            application.run_polling(allowed_updates=Update.ALL_TYPES)

        except Exception as e:
            logger.error(f"Critical error occurred: {str(e)}")
            retry_count += 1

            if retry_count < max_retries:
                logger.info(f"Bot crashed, attempting restart in {retry_delay} seconds... (Attempt {retry_count}/{max_retries})")
                time.sleep(retry_delay)
                continue
            else:
                logger.critical("Maximum retry attempts reached. Please check the logs and restart manually.")
                sys.exit(1)

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
        sys.exit(0)
    except Exception as e:
        logger.critical(f"Fatal error occurred: {str(e)}")
        sys.exit(1)