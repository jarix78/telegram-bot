from flask import Flask
from threading import Thread
import logging
import time

# Set up logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

app = Flask('')

@app.route('/')
def home():
    return "Bot is alive and running! 🚀"

def run():
    try:
        app.run(host='0.0.0.0', port=3000, debug=False, threaded=True)
    except Exception as e:
        logger.error(f"Server error occurred: {str(e)}")
        time.sleep(5)  # Wait 5 seconds before retry
        # Attempt to restart the server
        run()

def keep_alive():
    """
    Creates and starts a new thread running the Flask server
    to keep the bot alive 24/7.
    """
    try:
        server = Thread(target=run)
        server.daemon = True  # Set as daemon thread
        server.start()
        logger.info("Keep alive server started successfully - Bot will stay online 24/7")
    except Exception as e:
        logger.error(f"Failed to start keep alive server: {str(e)}")
        time.sleep(5)  # Wait 5 seconds before retry
        # Attempt to restart if thread creation fails
        keep_alive()