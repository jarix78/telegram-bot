import numpy as np
from typing import List, Tuple
import logging

logger = logging.getLogger(__name__)

def calculate_sma(prices: List[float], period: int = 14) -> float:
    """Calculate Simple Moving Average"""
    try:
        if len(prices) < period:
            raise ValueError(f"Not enough data points for {period} period SMA")
        return sum(prices[-period:]) / period
    except Exception as e:
        logger.error(f"Error calculating SMA: {str(e)}")
        return prices[-1]  # Return last price as fallback

def calculate_rsi(prices: List[float], period: int = 14) -> float:
    """Calculate Relative Strength Index"""
    try:
        if len(prices) < period + 1:
            raise ValueError(f"Not enough data points for {period} period RSI")
            
        deltas = np.diff(prices)
        gains = np.where(deltas > 0, deltas, 0)
        losses = np.where(deltas < 0, -deltas, 0)
        
        avg_gain = np.mean(gains[-period:])
        avg_loss = np.mean(losses[-period:])
        
        if avg_loss == 0:
            return 100
        
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        return rsi
        
    except Exception as e:
        logger.error(f"Error calculating RSI: {str(e)}")
        return 50  # Return neutral RSI as fallback

def calculate_macd(prices: List[float]) -> Tuple[float, float, float]:
    """Calculate MACD (Moving Average Convergence Divergence)"""
    try:
        if len(prices) < 26:
            raise ValueError("Not enough data points for MACD")
            
        # Calculate EMAs
        ema12 = np.array(prices).ewm(span=12, adjust=False).mean()
        ema26 = np.array(prices).ewm(span=26, adjust=False).mean()
        
        # Calculate MACD line and signal line
        macd_line = ema12[-1] - ema26[-1]
        signal_line = np.array(prices).ewm(span=9, adjust=False).mean()[-1]
        histogram = macd_line - signal_line
        
        return macd_line, signal_line, histogram
        
    except Exception as e:
        logger.error(f"Error calculating MACD: {str(e)}")
        return 0, 0, 0  # Return neutral values as fallback

def analyze_trend(prices: List[float]) -> Tuple[str, float, dict]:
    """
    Analyze price trend using multiple technical indicators
    Returns: (trend_direction, confidence_score, indicators_data)
    """
    try:
        if len(prices) < 26:  # Minimum required for all indicators
            raise ValueError("Insufficient price data for technical analysis")
            
        # Calculate technical indicators
        sma20 = calculate_sma(prices, 20)
        rsi = calculate_rsi(prices)
        macd_line, signal_line, histogram = calculate_macd(prices)
        
        # Current price
        current_price = prices[-1]
        
        # Initialize scoring system
        score = 0
        max_score = 3
        
        # Analyze SMA trend
        if current_price > sma20:
            score += 1
        else:
            score -= 1
            
        # Analyze RSI
        if rsi > 70:
            score -= 1
        elif rsi < 30:
            score += 1
            
        # Analyze MACD
        if macd_line > signal_line:
            score += 1
        else:
            score -= 1
            
        # Calculate confidence and determine trend
        confidence = abs(score) / max_score * 100
        trend = "up 📈" if score > 0 else "down 📉"
        
        # Compile indicators data
        indicators = {
            "sma20": round(sma20, 4),
            "rsi": round(rsi, 2),
            "macd": {
                "line": round(macd_line, 4),
                "signal": round(signal_line, 4),
                "histogram": round(histogram, 4)
            }
        }
        
        return trend, confidence, indicators
        
    except Exception as e:
        logger.error(f"Error in trend analysis: {str(e)}")
        # Fallback to simple price comparison
        if len(prices) >= 2:
            trend = "up 📈" if prices[-1] > prices[-2] else "down 📉"
            return trend, 50.0, {}
        return "up 📈", 50.0, {}  # Default fallback
