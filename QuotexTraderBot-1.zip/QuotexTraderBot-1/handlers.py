import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
import asyncio
from constants import *
from utils import *
from models import User, Signal, get_db
from simulator import TradingSimulator

# Enable logging
logger = logging.getLogger(__name__)

async def show_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show menu with currency pairs"""
    keyboard = get_currency_keyboard()

    if hasattr(update, 'callback_query') and update.callback_query:
        # For callback queries (menu button clicks)
        await update.callback_query.edit_message_text(
            CHOOSE_CURRENCY,
            reply_markup=keyboard
        )
    else:
        # For direct commands
        await update.message.reply_text(
            CHOOSE_CURRENCY,
            reply_markup=keyboard
        )

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle the /start command"""
    # Store user in database
    db = get_db()
    try:
        user = db.query(User).filter(User.telegram_id == str(update.effective_user.id)).first()
        if not user:
            user = User(
                telegram_id=str(update.effective_user.id),
                username=update.effective_user.username
            )
            db.add(user)
            db.commit()
    except Exception as e:
        logger.error(f"Database error in start_command: {str(e)}")
    finally:
        db.close()

    # Initialize simulator for the user
    context.user_data['simulator'] = TradingSimulator()

    # Only send welcome message with menu button
    menu_button = InlineKeyboardMarkup([[
        InlineKeyboardButton("📱 Menu", callback_data="menu")
    ]])

    await update.message.reply_text(
        WELCOME_MESSAGE,
        parse_mode='HTML',
        reply_markup=menu_button
    )

async def menu_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle the /menu command"""
    await show_menu(update, context)

async def show_simulator_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show simulator menu with options"""
    simulator = context.user_data.get('simulator')
    if not simulator:
        context.user_data['simulator'] = TradingSimulator()
        simulator = context.user_data['simulator']

    stats = simulator.get_stats()

    menu_text = f"""🎮 Trading Simulator

💰 Balance: ${stats['current_balance']:.2f}
📊 P/L: ${stats['total_profit_loss']:.2f} ({stats['roi']:.1f}%)
📈 Win Rate: {stats['win_rate']:.1f}%
🔄 Total Trades: {stats['total_trades']}

Select an action:"""

    keyboard = [
        [
            InlineKeyboardButton("📊 New Trade", callback_data="sim_trade"),
            InlineKeyboardButton("📈 Open Positions", callback_data="sim_positions")
        ],
        [
            InlineKeyboardButton("💰 Account Stats", callback_data="sim_stats"),
            InlineKeyboardButton("🔄 Reset Simulator", callback_data="sim_reset")
        ],
        [InlineKeyboardButton("📱 Main Menu", callback_data="menu")]
    ]

    if hasattr(update, 'callback_query') and update.callback_query:
        await update.callback_query.edit_message_text(
            menu_text,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    else:
        await update.message.reply_text(
            menu_text,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle button callbacks"""
    query = update.callback_query

    try:
        logger.info(f"Received callback data: {query.data}")
        await query.answer()

        if query.data == "menu":
            logger.info("Processing menu button callback")
            await show_menu(update, context)
            return

        if query.data == "simulator":
            await show_simulator_menu(update, context)
            return

        if query.data == "sim_reset":
            context.user_data['simulator'] = TradingSimulator()
            await show_simulator_menu(update, context)
            return

        if query.data == "sim_positions":
            simulator = context.user_data.get('simulator')
            if not simulator:
                await query.edit_message_text(
                    "⚠️ Simulator not initialized. Please restart with /start",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton("📱 Menu", callback_data="menu")
                    ]])
                )
                return

            positions = simulator.open_positions
            if not positions:
                message = "No open positions."
            else:
                message = "📊 Open Positions:\n\n"
                for pos in positions:
                    message += f"Pair: {pos['currency_pair']}\n"
                    message += f"Direction: {pos['direction']}\n"
                    message += f"Amount: ${pos['amount']:.2f}\n"
                    message += f"Entry: {pos['entry_price']:.5f}\n"
                    message += f"Time: {pos['entry_time']}\n\n"

            keyboard = [
                [InlineKeyboardButton("🔙 Back", callback_data="simulator")]
            ]
            await query.edit_message_text(
                message,
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
            return


        if query.data.startswith("pair_"):
            logger.info(f"Processing currency pair selection: {query.data}")
            currency_pair = query.data.replace("pair_", "")
            context.user_data['currency_pair'] = currency_pair

            keyboard = get_timeframe_keyboard()
            await query.edit_message_text(
                CHOOSE_TIMEFRAME,
                reply_markup=keyboard
            )
            return

        if query.data.startswith("time_"):
            logger.info(f"Processing timeframe selection: {query.data}")
            timeframe = query.data.replace("time_", "")
            currency_pair = context.user_data.get('currency_pair')

            await query.edit_message_text(ANALYZING)
            await asyncio.sleep(4)  # Wait for 4 seconds

            # Pass currency pair to generate_signal
            direction, news, volatility = generate_signal(currency_pair)
            logger.info(f"Generated signal for {currency_pair}: direction={direction}")

            # Store signal in database
            db = get_db()
            try:
                user = db.query(User).filter(User.telegram_id == str(update.effective_user.id)).first()
                if user:
                    signal = Signal(
                        user_id=user.id,
                        currency_pair=currency_pair,
                        timeframe=timeframe,
                        direction=direction,
                        news=news,
                        volatility=volatility
                    )
                    db.add(signal)
                    db.commit()
            except Exception as e:
                logger.error(f"Database error in button_callback: {str(e)}")
            finally:
                db.close()

            signal_message = f"""💹 Currency pair: {currency_pair}
🕐 Expired Time: {timeframe}
📊 Technical Analysis:
   • Direction: {direction}
   • Market Sentiment: {news}
   • Market Volatility: {volatility}
⚡Trading Signal: The technical analysis suggests opening a deal for {direction}
⏰ Recommended timeframe: {timeframe}"""

            keyboard = InlineKeyboardMarkup([[
                InlineKeyboardButton("📱 Menu", callback_data="menu")
            ]])

            await query.edit_message_text(
                signal_message,
                reply_markup=keyboard
            )

            context.user_data.clear()
            return

    except Exception as e:
        logger.error(f"Error in button callback: {str(e)}", exc_info=True)
        await query.edit_message_text(
            "⚠️ An error occurred. Please use /start to try again.",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("📱 Menu", callback_data="menu")
            ]])
        )

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle errors"""
    logger.error(f"Error occurred: {context.error}", exc_info=True)
    if update and update.effective_message:
        await update.effective_message.reply_text(
            "⚠️ An error occurred. Please use /start to try again."
        )