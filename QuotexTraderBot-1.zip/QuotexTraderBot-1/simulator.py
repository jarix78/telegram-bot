import logging
from datetime import datetime, timedelta
from typing import List, Dict, Tuple
import numpy as np
from technical_analysis import analyze_trend
from market_data import get_forex_data, MarketDataError

logger = logging.getLogger(__name__)

class TradingSimulator:
    def __init__(self, initial_balance: float = 10000.0):
        self.initial_balance = initial_balance
        self.balance = initial_balance
        self.open_positions: List[Dict] = []
        self.trade_history: List[Dict] = []
        self.profit_loss = 0.0
        
    def open_position(self, currency_pair: str, amount: float, direction: str, entry_price: float) -> Dict:
        """Open a new trading position"""
        if amount > self.balance:
            raise ValueError("Insufficient funds for trade")
            
        position = {
            'currency_pair': currency_pair,
            'amount': amount,
            'direction': direction,
            'entry_price': entry_price,
            'entry_time': datetime.utcnow(),
            'status': 'open'
        }
        
        self.balance -= amount
        self.open_positions.append(position)
        return position
        
    def close_position(self, position: Dict, exit_price: float) -> float:
        """Close a trading position and calculate profit/loss"""
        if position['status'] != 'open':
            raise ValueError("Position already closed")
            
        profit = 0.0
        if position['direction'] == 'up 📈':
            profit = (exit_price - position['entry_price']) * position['amount']
        else:
            profit = (position['entry_price'] - exit_price) * position['amount']
            
        position['exit_price'] = exit_price
        position['exit_time'] = datetime.utcnow()
        position['profit_loss'] = profit
        position['status'] = 'closed'
        
        self.balance += position['amount'] + profit
        self.profit_loss += profit
        self.trade_history.append(position)
        self.open_positions.remove(position)
        
        return profit
        
    def get_stats(self) -> Dict:
        """Get current simulation statistics"""
        total_trades = len(self.trade_history)
        winning_trades = len([t for t in self.trade_history if t['profit_loss'] > 0])
        
        return {
            'initial_balance': self.initial_balance,
            'current_balance': self.balance,
            'total_profit_loss': self.profit_loss,
            'open_positions': len(self.open_positions),
            'total_trades': total_trades,
            'winning_trades': winning_trades,
            'win_rate': (winning_trades / total_trades * 100) if total_trades > 0 else 0,
            'roi': ((self.balance - self.initial_balance) / self.initial_balance * 100)
        }
        
    async def analyze_trade(self, currency_pair: str) -> Tuple[str, float, Dict]:
        """Analyze current market conditions and suggest trade"""
        try:
            # Get market data
            data = get_forex_data(currency_pair.split('/')[0], currency_pair.split('/')[1])
            time_series = data.get('Time Series FX (1min)', {})
            
            if not time_series:
                raise MarketDataError("No data available for analysis")
                
            # Extract prices
            timestamps = sorted(time_series.keys())
            prices = [float(time_series[timestamp]['4. close']) for timestamp in timestamps]
            current_price = prices[-1]
            
            # Run technical analysis
            direction, confidence, indicators = analyze_trend(prices)
            
            return direction, current_price, indicators
            
        except Exception as e:
            logger.error(f"Error analyzing trade: {str(e)}")
            raise
