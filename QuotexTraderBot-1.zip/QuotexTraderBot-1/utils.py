import random
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from constants import CURRENCY_PAIRS, TIME_FRAMES
from market_data import analyze_market_data
import logging

logger = logging.getLogger(__name__)

def get_currency_keyboard():
    """Create inline keyboard for currency pairs"""
    keyboard = []
    row = []
    for i, pair in enumerate(CURRENCY_PAIRS):
        row.append(InlineKeyboardButton(pair, callback_data=f"pair_{pair}"))
        if len(row) == 2 or i == len(CURRENCY_PAIRS) - 1:
            keyboard.append(row)
            row = []

    # Add menu button at the bottom
    keyboard.append([InlineKeyboardButton("📱 Menu", callback_data="menu")])
    return InlineKeyboardMarkup(keyboard)

def get_timeframe_keyboard():
    """Create inline keyboard for timeframes"""
    keyboard = []
    row = []
    for i, timeframe in enumerate(TIME_FRAMES):
        row.append(InlineKeyboardButton(timeframe, callback_data=f"time_{timeframe}"))
        if len(row) == 2 or i == len(TIME_FRAMES) - 1:
            keyboard.append(row)
            row = []

    # Add menu button
    keyboard.append([InlineKeyboardButton("📱 Menu", callback_data="menu")])
    return InlineKeyboardMarkup(keyboard)

def generate_signal(currency_pair=None):
    """Generate trading signal based on real market data"""
    if currency_pair:
        try:
            return analyze_market_data(currency_pair)
        except Exception as e:
            logger.error(f"Error generating real market signal: {str(e)}")
            logger.info("Falling back to random signal generation")

    # Fallback to random generation if no currency pair or error occurs
    direction = "up 📈" if random.random() > 0.5 else "down 📉"
    news = "Positive" if random.random() > 0.5 else "Negative"
    volatility = "Increase" if random.random() > 0.5 else "Decrease"
    return direction, news, volatility