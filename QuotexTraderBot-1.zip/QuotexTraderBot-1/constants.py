# Bot token
TOKEN = "7787299392:AAFQhVQ42yi6oEpk32QRBFp9xOH2el1P1ig"

# Welcome message
WELCOME_MESSAGE = """This bot is based on artificial intelligence🤖 and machine learning. Our neural network analyzes the situation in market📈, the news and the chart itself📊 Based on this information and machine learning, he understands in which direction the market is moving and gives trading signals with 87% pass rate👍✅ This bot will allow you to trade on the binary options market and get guaranteed 💸profit💸 without any special knowledge in trading and technical analysis"""

# Currency pairs
CURRENCY_PAIRS = [
    "EUR/USD",
    "USD/JPY",
    "GBP/USD",
    "USD/CHF",
    "AUD/USD",
    "USD/CAD",
    "NZD/USD"
]

# Time frames
TIME_FRAMES = [
    "15 Second",
    "30 Second",
    "1minutes",
    "5 minutes"
]

# Messages
CHOOSE_CURRENCY = "💹 choose a currency pair from list below ⬇"
CHOOSE_TIMEFRAME = "⏰ Choose an expiration time"
ANALYZING = "♻️ The bot is analyzing wait~4 Seconds"

# Simulator messages
SIMULATOR_WELCOME = """Welcome to the Trading Simulator! 🎮

Here you can practice trading strategies without risking real money. You'll start with a virtual balance of $10,000.

Features:
• Real-time market data analysis
• Technical indicators
• Performance tracking
• Risk-free trading practice

Select an option below to begin:"""

INSUFFICIENT_FUNDS = "❌ Insufficient funds for this trade"
TRADE_SUCCESSFUL = "✅ Trade executed successfully!"
POSITION_CLOSED = "Position closed - P/L: ${profit:.2f}"