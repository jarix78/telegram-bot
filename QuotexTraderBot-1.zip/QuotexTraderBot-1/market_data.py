import os
import requests
import logging
from datetime import datetime, timedelta
from typing import Dict, Tuple, Optional, List
import numpy as np
from technical_analysis import analyze_trend

logger = logging.getLogger(__name__)

ALPHA_VANTAGE_API_KEY = os.environ.get('ALPHA_VANTAGE_API_KEY')
BASE_URL = 'https://www.alphavantage.co/query'

class MarketDataError(Exception):
    """Custom exception for market data related errors"""
    pass

def get_forex_data(from_currency: str, to_currency: str) -> Dict:
    """
    Fetch real-time forex data from Alpha Vantage
    """
    try:
        params = {
            'function': 'FX_INTRADAY',
            'from_symbol': from_currency,
            'to_symbol': to_currency,
            'interval': '1min',
            'outputsize': 'full',  # Get more data points for technical analysis
            'apikey': ALPHA_VANTAGE_API_KEY
        }

        response = requests.get(BASE_URL, params=params)
        response.raise_for_status()
        data = response.json()

        if "Error Message" in data:
            raise MarketDataError(f"Alpha Vantage API error: {data['Error Message']}")

        return data

    except requests.RequestException as e:
        logger.error(f"Failed to fetch forex data: {str(e)}")
        raise MarketDataError(f"Failed to fetch forex data: {str(e)}")

def extract_prices(time_series: Dict) -> List[float]:
    """Extract closing prices from time series data"""
    try:
        # Sort timestamps to ensure correct order
        timestamps = sorted(time_series.keys())
        # Extract closing prices
        prices = [float(time_series[timestamp]['4. close']) for timestamp in timestamps]
        return prices
    except (KeyError, ValueError) as e:
        logger.error(f"Error extracting prices: {str(e)}")
        raise MarketDataError("Failed to extract price data")

def analyze_market_data(currency_pair: str) -> Tuple[str, str, str]:
    """
    Analyze forex data and generate trading signals based on technical analysis
    Returns: (direction, news_impact, volatility)
    """
    try:
        # Split currency pair (e.g., "EUR/USD" -> "EUR", "USD")
        from_currency, to_currency = currency_pair.split('/')

        # Get real-time forex data
        data = get_forex_data(from_currency, to_currency)
        time_series = data.get('Time Series FX (1min)', {})

        if not time_series:
            raise MarketDataError("No data available")

        # Extract price data
        prices = extract_prices(time_series)
        if len(prices) < 26:  # Minimum required for technical analysis
            raise MarketDataError("Insufficient data points")

        # Perform technical analysis
        direction, confidence, indicators = analyze_trend(prices)

        # Calculate volatility
        price_changes = np.diff(prices[-20:]) / prices[-21:-1] * 100
        volatility = "High" if np.std(price_changes) > 0.1 else "Low"

        # Determine market sentiment based on technical indicators
        rsi = indicators.get('rsi', 50)
        if rsi > 70:
            news = "Overbought"
        elif rsi < 30:
            news = "Oversold"
        else:
            news = "Neutral"

        logger.info(f"Technical Analysis Results - Direction: {direction}, RSI: {rsi}, Volatility: {volatility}")
        return direction, news, volatility

    except (MarketDataError, KeyError, ValueError, ZeroDivisionError) as e:
        logger.error(f"Error analyzing market data: {str(e)}")
        # Fallback to random signals in case of error
        from utils import generate_signal
        return generate_signal()